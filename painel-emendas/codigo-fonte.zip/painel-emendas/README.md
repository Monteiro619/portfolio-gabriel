# Emenda — Painel de Emendas Parlamentares

Projeto demonstrativo de Gabriel Monteiro Ramos. Apresenta competências em acompanhamento parlamentar, gestão da informação, análise de dados e desenvolvimento web.

## Experiência

60 emendas fictícias entre 2024 e 2026. Filtros por exercício, município, área, tipo e situação; busca; indicadores; gráficos; tabela paginada e ordenação; cadastro e edição; importação e exportação CSV; consolidação municipal e impressão do recorte completo.

As cidades são reais, mas todos os códigos, beneficiários e valores são fictícios. Não há integração com sistemas oficiais. A base é salva no navegador via localStorage quando disponível. Não existe sincronização entre dispositivos.

## Executar

Abra `dist/index.html` em um navegador moderno ou sirva a pasta `dist` com um servidor estático. Não requer instalação de dependências nem chaves de API. Fontes externas são opcionais e têm alternativas locais.

## Dados e indicadores

Indicado é o valor de referência; empenhado, liquidado e pago são valores acumulados de etapas diferentes e não devem ser somados entre si. O indicador de execução financeira é pago / indicado; não mede execução física ou entrega do objeto. A situação é derivada dos valores para esta demonstração, sem reproduzir todas as situações administrativas possíveis.

CSV com separador ponto e vírgula, UTF-8 e cabeçalho `id;ano;municipio;uf;area;tipo;beneficiario;objeto;indicado;empenhado;liquidado;pago`. Valores numéricos usam ponto decimal, sem separador de milhar. A importação valida todos os registros antes de substituir a base, solicita confirmação e exige pago ≤ liquidado ≤ empenhado ≤ indicado. Registros com zero indicado são permitidos e resultam em percentual zero.

## Tecnologias

HTML, CSS e JavaScript sem dependências de execução. Modelo de dados separado em `dist/model.js`. Interface em `dist/app.js`. Layout responsivo, HTML semântico, foco visível, modal nativo e escape de textos importados.

## Verificação

Execute `node tests/model.test.cjs`. Os testes verificam consistência da base, totais, filtros, validação e importação/exportação de CSV. A verificação visual em navegador não foi executada no ambiente de criação.
